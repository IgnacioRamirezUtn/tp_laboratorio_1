
#include <stdio.h>
#ifndef TP_H_
#define TP_H_



float sumar(float operador1, float operador2);
float restar(float operador1, float operador2);
float multiplicar(float operador1, float operador2);
float dividir (float operador1, float operador2);
int factorizar (float operador);



#endif /* TP_H_ */
